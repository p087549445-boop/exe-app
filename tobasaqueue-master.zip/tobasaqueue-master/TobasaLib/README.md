# Tobasa Library

https://github.com/jefrisibarani/tobasaqueue
http://www.mangapul.net/p/software-antrian-tobasa.html


A lightweight library used by the Tobasa Queue System.

It provides an asynchronous TCP queue server, a DirectShow wrapper, a simple database query wrapper, and a logging utility class


##### Copyright (C) 2015-2025 Jefri Sibarani